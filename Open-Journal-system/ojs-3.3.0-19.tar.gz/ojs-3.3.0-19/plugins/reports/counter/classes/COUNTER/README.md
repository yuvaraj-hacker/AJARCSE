# COUNTER Reports classes

Convenience interface to PHP's DOMDocument for the Project COUNTER schema

Copyright 2015 (c) University of Pittsburgh

Licensed under GPL 2.0 or later

## DESCRIPTION

See the PHPDoc for COUNTER.php for DESCRIPTION
