# Native Import/Export Plugin

## Documentation

See https://docs.pkp.sfu.ca/admin-guide/en/data-import-and-export#native-xml-plugin
for documentation.

## Sample XML

Sample XML can be found in https://github.com/pkp/ojs/blob/[tag]/cypress/fixtures/export-issues.xml,
where [tag] indicates your version of OJS, e.g.: 3_2_1-0 for OJS 3.1.2-0.
